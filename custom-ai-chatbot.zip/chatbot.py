from openai import OpenAI
from config import OPENAI_API_KEY

client = OpenAI(api_key=OPENAI_API_KEY)

class ChatBot:
    def __init__(self):
        self.history = []

    def add_message(self, role, content):
        self.history.append({"role": role, "content": content})

    def trim_history(self, max_messages=20):
        if len(self.history) > max_messages:
            self.history = self.history[-max_messages:]

    def get_response(self, user_input):
        self.add_message("user", user_input)
        self.trim_history()
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=self.history
        )
        answer = response.choices[0].message.content
        self.add_message("assistant", answer)
        return answer
