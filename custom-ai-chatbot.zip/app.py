from chatbot import ChatBot
from memory_manager import save_chat, load_chat, clear_chat

bot = ChatBot()
bot.history = load_chat()

print("Custom AI Chatbot with Memory")
while True:
    user_input = input("You: ")
    if user_input.lower() == "exit":
        save_chat(bot.history)
        break
    if user_input.lower() == "clear":
        bot.history = []
        clear_chat()
        print("Memory cleared")
        continue
    print("AI:", bot.get_response(user_input))
