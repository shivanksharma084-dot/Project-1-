import streamlit as st
from chatbot import ChatBot

if "bot" not in st.session_state:
    st.session_state.bot = ChatBot()

st.title("Custom AI Chatbot with Memory")
msg = st.chat_input("Ask anything")

if msg:
    st.chat_message("user").write(msg)
    st.chat_message("assistant").write(
        st.session_state.bot.get_response(msg)
    )

if st.button("Clear Memory"):
    st.session_state.bot.history = []
