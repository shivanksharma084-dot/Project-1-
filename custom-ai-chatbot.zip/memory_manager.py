import json, os
CHAT_FILE = "chat_history.json"

def save_chat(history):
    with open(CHAT_FILE, "w") as f:
        json.dump(history, f, indent=4)

def load_chat():
    if os.path.exists(CHAT_FILE):
        with open(CHAT_FILE, "r") as f:
            return json.load(f)
    return []

def clear_chat():
    if os.path.exists(CHAT_FILE):
        os.remove(CHAT_FILE)
